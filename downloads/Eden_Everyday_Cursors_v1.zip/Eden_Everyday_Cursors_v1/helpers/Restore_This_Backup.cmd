@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Eden Everyday - Restore saved cursor settings
if not defined LOCALAPPDATA goto failed
set "EDEN_ROOT=%LOCALAPPDATA%\EdenCursorTheme"
set "EDEN_BACKUP=%~dp0."
if not exist "%EDEN_BACKUP%\cursors-before.reg" goto missing_backup
echo This restores the cursor settings saved in this folder:
echo "%EDEN_BACKUP%"
echo A new recovery snapshot of the current cursor settings is saved first.
echo.
:choose_recovery
set "EDEN_UNDO=%EDEN_ROOT%\Backups\undo-restore-%RANDOM%-%RANDOM%-%RANDOM%"
if exist "%EDEN_UNDO%\" goto choose_recovery
mkdir "%EDEN_UNDO%" >nul 2>nul
if errorlevel 1 goto backup_failed
reg.exe export "HKCU\Control Panel\Cursors" "%EDEN_UNDO%\cursors-before.reg" >nul 2>nul
if errorlevel 1 goto backup_failed
reg.exe query "HKCU\Control Panel\Cursors" /v "Arrow" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-Arrow.marker"
  if not exist "%EDEN_UNDO%\missing-Arrow.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Help" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-Help.marker"
  if not exist "%EDEN_UNDO%\missing-Help.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "AppStarting" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-AppStarting.marker"
  if not exist "%EDEN_UNDO%\missing-AppStarting.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Wait" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-Wait.marker"
  if not exist "%EDEN_UNDO%\missing-Wait.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Crosshair" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-Crosshair.marker"
  if not exist "%EDEN_UNDO%\missing-Crosshair.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "IBeam" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-IBeam.marker"
  if not exist "%EDEN_UNDO%\missing-IBeam.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "NWPen" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-NWPen.marker"
  if not exist "%EDEN_UNDO%\missing-NWPen.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "No" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-No.marker"
  if not exist "%EDEN_UNDO%\missing-No.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeNS" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-SizeNS.marker"
  if not exist "%EDEN_UNDO%\missing-SizeNS.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeWE" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-SizeWE.marker"
  if not exist "%EDEN_UNDO%\missing-SizeWE.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeNWSE" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-SizeNWSE.marker"
  if not exist "%EDEN_UNDO%\missing-SizeNWSE.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeNESW" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-SizeNESW.marker"
  if not exist "%EDEN_UNDO%\missing-SizeNESW.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeAll" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-SizeAll.marker"
  if not exist "%EDEN_UNDO%\missing-SizeAll.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "UpArrow" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-UpArrow.marker"
  if not exist "%EDEN_UNDO%\missing-UpArrow.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Hand" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-Hand.marker"
  if not exist "%EDEN_UNDO%\missing-Hand.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Pin" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-Pin.marker"
  if not exist "%EDEN_UNDO%\missing-Pin.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Person" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-Person.marker"
  if not exist "%EDEN_UNDO%\missing-Person.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /ve >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-default.marker"
  if not exist "%EDEN_UNDO%\missing-default.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Scheme Source" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-SchemeSource.marker"
  if not exist "%EDEN_UNDO%\missing-SchemeSource.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 48" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-scheme-48.marker"
  if not exist "%EDEN_UNDO%\missing-scheme-48.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 40" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_UNDO%\missing-scheme-40.marker"
  if not exist "%EDEN_UNDO%\missing-scheme-40.marker" goto backup_failed
)
copy /b "%~f0" "%EDEN_UNDO%\Restore_This_Backup.cmd" >nul
if errorlevel 1 goto backup_failed
reg.exe import "%EDEN_BACKUP%\cursors-before.reg" >nul 2>nul
if errorlevel 1 goto import_failed
if exist "%EDEN_BACKUP%\missing-Arrow.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Arrow" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Help.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Help" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-AppStarting.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "AppStarting" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Wait.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Wait" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Crosshair.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Crosshair" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-IBeam.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "IBeam" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-NWPen.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "NWPen" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-No.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "No" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeNS.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeNS" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeWE.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeWE" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeNWSE.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeNWSE" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeNESW.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeNESW" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeAll.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeAll" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-UpArrow.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "UpArrow" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Hand.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Hand" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Pin.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Pin" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Person.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Person" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-default.marker" reg.exe delete "HKCU\Control Panel\Cursors" /ve /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SchemeSource.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Scheme Source" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-scheme-48.marker" reg.exe delete "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 48" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-scheme-40.marker" reg.exe delete "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 40" /f >nul 2>nul
echo.
echo The saved cursor registry settings were restored.
echo Review the original scheme in Mouse Properties and choose Apply.
echo If Apply is unavailable, sign out and sign back in to reload that saved state.
echo This script does not force an immediate cursor refresh.
echo To undo this restore, use the recovery script in:
echo "%EDEN_UNDO%"
start "" control.exe main.cpl,,1
echo.
pause
exit /b 0
:backup_failed
echo Could not back up the current cursor state. Restore was not performed.
goto failed
:import_failed
echo Windows could not import the complete saved cursor state.
echo The state from before this attempt is backed up here:
echo "%EDEN_UNDO%"
goto failed
:missing_backup
echo No cursors-before.reg exists next to this recovery script.
:failed
echo.
pause
exit /b 1
