@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Eden Everyday - Install
if not defined LOCALAPPDATA goto no_localappdata
set "EDEN_ROOT=%LOCALAPPDATA%\EdenCursorTheme"
if not "%EDEN_ROOT:,=%"=="%EDEN_ROOT%" goto comma_path
if not exist "%~dp0cursors\48\eden-normal.ani" goto source_missing
if not exist "%~dp0cursors\48\eden-help.ani" goto source_missing
if not exist "%~dp0cursors\48\eden-working.ani" goto source_missing
if not exist "%~dp0cursors\48\eden-busy.ani" goto source_missing
if not exist "%~dp0cursors\48\eden-precision.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-text.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-handwriting.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-unavailable.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-resize-ns.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-resize-we.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-resize-nwse.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-resize-nesw.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-move.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-alternate.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-link.ani" goto source_missing
if not exist "%~dp0cursors\48\eden-location.cur" goto source_missing
if not exist "%~dp0cursors\48\eden-person.ani" goto source_missing
if not exist "%~dp0cursors\40\eden-normal.ani" goto source_missing
if not exist "%~dp0cursors\40\eden-help.ani" goto source_missing
if not exist "%~dp0cursors\40\eden-working.ani" goto source_missing
if not exist "%~dp0cursors\40\eden-busy.ani" goto source_missing
if not exist "%~dp0cursors\40\eden-precision.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-text.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-handwriting.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-unavailable.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-resize-ns.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-resize-we.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-resize-nwse.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-resize-nesw.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-move.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-alternate.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-link.ani" goto source_missing
if not exist "%~dp0cursors\40\eden-location.cur" goto source_missing
if not exist "%~dp0cursors\40\eden-person.ani" goto source_missing
if not exist "%~dp0helpers\Restore_This_Backup.cmd" goto source_missing
reg.exe query "HKCU\Control Panel\Cursors" >nul 2>nul
if errorlevel 1 goto backup_failed
if not exist "%EDEN_ROOT%\Backups\" mkdir "%EDEN_ROOT%\Backups" >nul 2>nul
if not exist "%EDEN_ROOT%\Installs\" mkdir "%EDEN_ROOT%\Installs" >nul 2>nul
:choose_id
set "EDEN_ID=install-%RANDOM%-%RANDOM%-%RANDOM%"
set "EDEN_BACKUP=%EDEN_ROOT%\Backups\%EDEN_ID%"
set "EDEN_TARGET=%EDEN_ROOT%\Installs\%EDEN_ID%"
if exist "%EDEN_BACKUP%\" goto choose_id
if exist "%EDEN_TARGET%\" goto choose_id
mkdir "%EDEN_BACKUP%" >nul 2>nul
if errorlevel 1 goto backup_failed
reg.exe export "HKCU\Control Panel\Cursors" "%EDEN_BACKUP%\cursors-before.reg" >nul 2>nul
if errorlevel 1 goto backup_failed
reg.exe query "HKCU\Control Panel\Cursors" /v "Arrow" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-Arrow.marker"
  if not exist "%EDEN_BACKUP%\missing-Arrow.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Help" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-Help.marker"
  if not exist "%EDEN_BACKUP%\missing-Help.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "AppStarting" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-AppStarting.marker"
  if not exist "%EDEN_BACKUP%\missing-AppStarting.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Wait" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-Wait.marker"
  if not exist "%EDEN_BACKUP%\missing-Wait.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Crosshair" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-Crosshair.marker"
  if not exist "%EDEN_BACKUP%\missing-Crosshair.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "IBeam" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-IBeam.marker"
  if not exist "%EDEN_BACKUP%\missing-IBeam.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "NWPen" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-NWPen.marker"
  if not exist "%EDEN_BACKUP%\missing-NWPen.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "No" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-No.marker"
  if not exist "%EDEN_BACKUP%\missing-No.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeNS" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-SizeNS.marker"
  if not exist "%EDEN_BACKUP%\missing-SizeNS.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeWE" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-SizeWE.marker"
  if not exist "%EDEN_BACKUP%\missing-SizeWE.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeNWSE" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-SizeNWSE.marker"
  if not exist "%EDEN_BACKUP%\missing-SizeNWSE.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeNESW" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-SizeNESW.marker"
  if not exist "%EDEN_BACKUP%\missing-SizeNESW.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "SizeAll" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-SizeAll.marker"
  if not exist "%EDEN_BACKUP%\missing-SizeAll.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "UpArrow" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-UpArrow.marker"
  if not exist "%EDEN_BACKUP%\missing-UpArrow.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Hand" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-Hand.marker"
  if not exist "%EDEN_BACKUP%\missing-Hand.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Pin" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-Pin.marker"
  if not exist "%EDEN_BACKUP%\missing-Pin.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Person" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-Person.marker"
  if not exist "%EDEN_BACKUP%\missing-Person.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /ve >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-default.marker"
  if not exist "%EDEN_BACKUP%\missing-default.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors" /v "Scheme Source" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-SchemeSource.marker"
  if not exist "%EDEN_BACKUP%\missing-SchemeSource.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 48" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-scheme-48.marker"
  if not exist "%EDEN_BACKUP%\missing-scheme-48.marker" goto backup_failed
)
reg.exe query "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 40" >nul 2>nul
if errorlevel 1 (
  type nul > "%EDEN_BACKUP%\missing-scheme-40.marker"
  if not exist "%EDEN_BACKUP%\missing-scheme-40.marker" goto backup_failed
)
copy /b "%~dp0helpers\Restore_This_Backup.cmd" "%EDEN_BACKUP%\Restore_This_Backup.cmd" >nul
if errorlevel 1 goto backup_failed
mkdir "%EDEN_TARGET%" >nul 2>nul
if errorlevel 1 goto copy_failed
xcopy.exe "%~dp0cursors" "%EDEN_TARGET%\cursors\" /E /I /H /Y >nul
if errorlevel 1 goto copy_failed
reg.exe add "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 48" /t REG_SZ /d "%EDEN_TARGET%\cursors\48\eden-normal.ani,%EDEN_TARGET%\cursors\48\eden-help.ani,%EDEN_TARGET%\cursors\48\eden-working.ani,%EDEN_TARGET%\cursors\48\eden-busy.ani,%EDEN_TARGET%\cursors\48\eden-precision.cur,%EDEN_TARGET%\cursors\48\eden-text.cur,%EDEN_TARGET%\cursors\48\eden-handwriting.cur,%EDEN_TARGET%\cursors\48\eden-unavailable.cur,%EDEN_TARGET%\cursors\48\eden-resize-ns.cur,%EDEN_TARGET%\cursors\48\eden-resize-we.cur,%EDEN_TARGET%\cursors\48\eden-resize-nwse.cur,%EDEN_TARGET%\cursors\48\eden-resize-nesw.cur,%EDEN_TARGET%\cursors\48\eden-move.cur,%EDEN_TARGET%\cursors\48\eden-alternate.cur,%EDEN_TARGET%\cursors\48\eden-link.ani,%EDEN_TARGET%\cursors\48\eden-location.cur,%EDEN_TARGET%\cursors\48\eden-person.ani" /f >nul 2>nul
if errorlevel 1 goto registration_failed
reg.exe add "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 40" /t REG_SZ /d "%EDEN_TARGET%\cursors\40\eden-normal.ani,%EDEN_TARGET%\cursors\40\eden-help.ani,%EDEN_TARGET%\cursors\40\eden-working.ani,%EDEN_TARGET%\cursors\40\eden-busy.ani,%EDEN_TARGET%\cursors\40\eden-precision.cur,%EDEN_TARGET%\cursors\40\eden-text.cur,%EDEN_TARGET%\cursors\40\eden-handwriting.cur,%EDEN_TARGET%\cursors\40\eden-unavailable.cur,%EDEN_TARGET%\cursors\40\eden-resize-ns.cur,%EDEN_TARGET%\cursors\40\eden-resize-we.cur,%EDEN_TARGET%\cursors\40\eden-resize-nwse.cur,%EDEN_TARGET%\cursors\40\eden-resize-nesw.cur,%EDEN_TARGET%\cursors\40\eden-move.cur,%EDEN_TARGET%\cursors\40\eden-alternate.cur,%EDEN_TARGET%\cursors\40\eden-link.ani,%EDEN_TARGET%\cursors\40\eden-location.cur,%EDEN_TARGET%\cursors\40\eden-person.ani" /f >nul 2>nul
if errorlevel 1 goto registration_failed
> "%EDEN_ROOT%\latest-backup-id.txt" echo %EDEN_ID%
if errorlevel 1 goto marker_failed
echo.
echo Eden Everyday 48 and Eden Everyday 40 are registered for this user.
echo Your current cursor scheme has NOT been switched by this installer.
echo In Mouse Properties, open Pointers, choose Eden Everyday 48, then Apply.
echo Eden Everyday 40 is the smaller alternative.
echo.
echo Cursor files:
echo "%EDEN_TARGET%"
echo Previous cursor settings and recovery script:
echo "%EDEN_BACKUP%"
start "" control.exe main.cpl,,1
echo.
pause
exit /b 0
:registration_failed
echo Scheme registration failed. Restoring the saved cursor registry snapshot.
reg.exe import "%EDEN_BACKUP%\cursors-before.reg" >nul 2>nul
if errorlevel 1 goto rollback_failed
if exist "%EDEN_BACKUP%\missing-Arrow.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Arrow" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Help.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Help" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-AppStarting.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "AppStarting" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Wait.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Wait" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Crosshair.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Crosshair" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-IBeam.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "IBeam" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-NWPen.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "NWPen" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-No.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "No" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeNS.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeNS" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeWE.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeWE" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeNWSE.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeNWSE" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeNESW.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeNESW" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SizeAll.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "SizeAll" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-UpArrow.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "UpArrow" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Hand.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Hand" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Pin.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Pin" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-Person.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Person" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-default.marker" reg.exe delete "HKCU\Control Panel\Cursors" /ve /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-SchemeSource.marker" reg.exe delete "HKCU\Control Panel\Cursors" /v "Scheme Source" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-scheme-48.marker" reg.exe delete "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 48" /f >nul 2>nul
if exist "%EDEN_BACKUP%\missing-scheme-40.marker" reg.exe delete "HKCU\Control Panel\Cursors\Schemes" /v "Eden Everyday 40" /f >nul 2>nul
echo Original cursor registry settings were re-imported.
goto failed
:rollback_failed
echo Automatic rollback could not complete. Keep this recovery folder:
echo "%EDEN_BACKUP%"
goto failed
:marker_failed
echo Schemes were registered but the latest-backup shortcut could not be saved.
echo To recover later, run Restore_This_Backup.cmd in this folder:
echo "%EDEN_BACKUP%"
start "" control.exe main.cpl,,1
goto failed
:backup_failed
echo Could not back up the current user's cursor settings. No scheme was registered.
goto failed
:copy_failed
echo Could not copy all cursor files. No scheme was registered.
echo A recovery snapshot, if created, remains in:
echo "%EDEN_BACKUP%"
goto failed
:source_missing
echo A required package file is missing. Extract the whole ZIP before installing.
goto failed
:comma_path
echo This user's LocalAppData path contains a comma, which conflicts with scheme lists.
echo Use the manual Mouse Properties instructions in README_KO.md instead.
goto failed
:no_localappdata
echo LOCALAPPDATA is unavailable. Run this inside a normal Windows user session.
:failed
echo.
pause
exit /b 1
