#Requires AutoHotkey v2.0
#SingleInstance Force
#MaxThreadsPerHotkey 1

; Eden Everyday — optional click and wheel reactions.
; The Windows cursor remains visible and every mouse event passes through.
; No network calls, keystroke logging, startup entries, or cursor-registry writes.

CoordMode "Mouse", "Screen"
SetWorkingDir A_ScriptDir
try DllCall("User32\SetThreadDpiAwarenessContext", "ptr", -4, "ptr")

EdenSize := 72
EdenEnabled := true
EdenKind := ""
EdenStarted := 0
EdenUntil := 0
EdenLastFrame := ""
EdenVisible := false
EdenFramePaths := Map()

for kind in ["click", "curious", "scroll-up", "scroll-down"] {
    frames := []
    Loop 6 {
        path := A_ScriptDir "\frames\" kind "\" Format("{:02}", A_Index - 1) ".png"
        if !FileExist(path) {
            MsgBox "A reaction image is missing:`n" path "`n`nExtract the entire ZIP before running Eden-Reactions.ahk.", "Eden Reactions"
            ExitApp
        }
        frames.Push(path)
    }
    EdenFramePaths[kind] := frames
}

; WS_EX_TRANSPARENT + WS_EX_NOACTIVATE; layered transparency is set below.
EdenWindow := Gui("+AlwaysOnTop +ToolWindow -DPIScale +E0x08000020", "Eden Reactions")
EdenWindow.MarginX := 0
EdenWindow.MarginY := 0
EdenWindow.BackColor := "010203"
EdenPicture := EdenWindow.AddPicture("x0 y0 w" EdenSize " h" EdenSize " BackgroundTrans", EdenFramePaths["click"][1])
WinSetTransColor "010203", EdenWindow.Hwnd
EdenWindow.Opt("-Caption")
OnExit StopEden

A_TrayMenu.Delete()
A_TrayMenu.Add("Pause reactions", ToggleEden)
A_TrayMenu.Add("Try a wink", (*) => ShowEden("click", 700))
A_TrayMenu.Add()
A_TrayMenu.Add("Exit Eden reactions", (*) => ExitApp())
A_IconTip := "Eden Reactions — click, right-click, and scroll"
try TraySetIcon(A_ScriptDir "\eden-tray.ico")

; ~ preserves the real click/scroll. * also accepts Ctrl/Shift/Alt-modified input.
~*LButton::ShowEden("click", 480)
~*RButton::ShowEden("curious", 620)
~*MButton::ShowEden("curious", 520)
~*WheelUp::ShowEden("scroll-up", 420)
~*WheelDown::ShowEden("scroll-down", 420)

ShowEden(kind, duration) {
    global EdenEnabled, EdenKind, EdenStarted, EdenUntil, EdenLastFrame, EdenVisible
    if !EdenEnabled || !NativeCursorVisible()
        return
    now := A_TickCount
    ; Repeated wheel ticks extend a reaction instead of restarting its first frame.
    if kind != EdenKind || !EdenVisible {
        EdenKind := kind
        EdenStarted := now
        EdenLastFrame := ""
    }
    EdenUntil := now + duration
    DrawEden()
    SetTimer DrawEden, 33
}

DrawEden() {
    global EdenEnabled, EdenKind, EdenStarted, EdenUntil, EdenLastFrame
    global EdenVisible, EdenFramePaths, EdenPicture, EdenWindow, EdenSize
    if !EdenEnabled || A_TickCount >= EdenUntil || !NativeCursorVisible() {
        HideEden()
        return
    }
    frames := EdenFramePaths[EdenKind]
    frameIndex := Mod(Floor((A_TickCount - EdenStarted) / 75), frames.Length) + 1
    path := frames[frameIndex]
    if path != EdenLastFrame {
        EdenPicture.Value := path
        EdenLastFrame := path
    }
    MouseGetPos &mouseX, &mouseY
    point := EdenPosition(mouseX, mouseY)
    if !EdenVisible {
        EdenWindow.Show("NoActivate x" point[1] " y" point[2] " w" EdenSize " h" EdenSize)
        EdenVisible := true
    } else {
        EdenWindow.Move(point[1], point[2], EdenSize, EdenSize)
    }
}

EdenPosition(mouseX, mouseY) {
    global EdenSize
    ; Keep the reaction beside the pointer and within its monitor's work area.
    left := SysGet(76)
    top := SysGet(77)
    right := left + SysGet(78)
    bottom := top + SysGet(79)
    Loop MonitorGetCount() {
        MonitorGetWorkArea A_Index, &l, &t, &r, &b
        if mouseX >= l && mouseX < r && mouseY >= t && mouseY < b {
            left := l, top := t, right := r, bottom := b
            break
        }
    }
    x := mouseX + 38
    y := mouseY + 20
    if x + EdenSize > right
        x := mouseX - EdenSize - 14
    if y + EdenSize > bottom
        y := mouseY - EdenSize - 14
    return [Max(left, Min(x, right - EdenSize)), Max(top, Min(y, bottom - EdenSize))]
}

NativeCursorVisible() {
    info := Buffer(A_PtrSize = 8 ? 24 : 20, 0)
    NumPut "uint", info.Size, info
    return DllCall("User32\GetCursorInfo", "ptr", info, "int") && (NumGet(info, 4, "uint") & 1)
}

HideEden() {
    global EdenWindow, EdenVisible
    SetTimer DrawEden, 0
    EdenWindow.Hide()
    EdenVisible := false
}

ToggleEden(*) {
    global EdenEnabled
    EdenEnabled := !EdenEnabled
    if EdenEnabled
        A_TrayMenu.Uncheck("Pause reactions")
    else {
        A_TrayMenu.Check("Pause reactions")
        HideEden()
    }
}

StopEden(*) {
    global EdenWindow
    SetTimer DrawEden, 0
    EdenWindow.Destroy()
}
