# 기술 근거와 구현 범위

## Windows 커서와 역할

- Microsoft Learn, **About Cursors**: 기본 커서 식별자, 32bpp ARGB, 핫스폿, `.cur`/`.ani`, DPI에 따른 커서 크기. <https://learn.microsoft.com/windows/win32/menurc/about-cursors>
- Microsoft Learn, **Theme File Format**: `[Control Panel\Cursors]`의 Arrow, Help, AppStarting, Wait, NWPen, IBeam, 크기 조정 등 역할별 파일 매핑. <https://learn.microsoft.com/en-us/windows/win32/controls/themesfileformat-overview>
- Microsoft Learn, **Resource File Formats**: DIB 기반 커서/아이콘의 XOR 이미지와 AND 마스크, RIFF 애니메이션 커서. <https://learn.microsoft.com/en-us/windows/win32/menurc/resource-file-formats>
- Microsoft, **Multimedia Data Standards Update**, 1994-04-15, ACON section (문서 표기 9–10쪽): RIFF ACON의 `anih`, `rate`, `seq `, `LIST fram`, 내장 CUR 파일. 재생 시간 단위는 1/60초 jiffy. Microsoft가 작성한 원문 사본을 McGill University가 제공. <https://www.mmsp.ece.mcgill.ca/Documents/AudioFormats/WAVE/Docs/RIFFNEW.pdf>

패키지의 17개 슬롯 순서는 Windows 포인터 구성표에서 사용되는 다음 순서입니다:

```text
Arrow, Help, AppStarting, Wait, Crosshair, IBeam, NWPen, No,
SizeNS, SizeWE, SizeNWSE, SizeNESW, SizeAll, UpArrow, Hand, Pin, Person
```

Windows가 제공하는 모든 내부 리소스 커서가 이 17개 사용자 구성표 슬롯에 포함되는 것은 아닙니다. 클릭·휠 이벤트 자체는 이 구성표에서 별도의 역할로 등록되지 않습니다.

## 설치·복원 방식

- Microsoft Learn, **reg export**: 지정한 레지스트리 키와 하위 키/값을 `.reg` 파일로 내보냄. <https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/reg-export>
- Microsoft Learn, **reg import**: 내보낸 레지스트리 값을 다시 가져옴. <https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/reg-import>
- Microsoft Learn, **reg add**: 지정한 값과 형식을 등록. <https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/reg-add>
- Microsoft Learn, **SystemParametersInfoW**: `SPI_SETCURSORS`로 시스템 커서를 다시 읽는 API를 문서화. 이 패키지의 CMD 설치·복원 스크립트는 해당 API를 호출하지 않으며 사용자가 마우스 속성에서 적용하도록 구성. <https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-systemparametersinfow>

설치 스크립트는 `HKCU\Control Panel\Cursors\Schemes`에 17개 파일 경로를 담은 두 사용자 구성표를 등록합니다. 이 레지스트리 구성표 목록은 Windows의 기존 저장 관례를 사용한 구현이며, Microsoft가 보장하는 별도 버전 관리 API로 취급하지 않습니다. 그래서 표준 마우스 속성의 개별 `.cur`/`.ani` 찾아보기 방식도 문서화했습니다. 설치기는 활성 역할 값을 직접 전환하지 않고 마우스 속성의 적용을 사용합니다.

`.inf`로 Windows 시스템 폴더에 설치하거나 PowerShell 실행 정책을 바꾸는 대신, 기본 제공 `cmd.exe`·`reg.exe`·`xcopy.exe`와 사용자 쓰기 가능한 LocalAppData 폴더를 사용합니다. 등록 전에 전체 커서 키를 내보내며, 원래 없던 역할·기본값·이든 구성표 값은 별도 표시해 복원 때 제거합니다. 재설치와 복원 직전 백업은 각각 새로운 폴더에 저장합니다. 복원은 이전 스냅샷을 가져오므로 이후의 커서 관련 변경에도 영향을 줄 수 있습니다.

## 선택 반응 프로그램

AutoHotkey v2 공식 문서:

- Hotkeys (`~`는 원래 입력을 통과시킴): <https://www.autohotkey.com/docs/v2/Hotkeys.htm>
- Gui (`NoActivate`, 캡션과 투명색 적용 순서): <https://www.autohotkey.com/docs/v2/lib/Gui.htm>
- Picture / PNG 지원: <https://www.autohotkey.com/docs/v2/lib/GuiControls.htm#Picture>
- WinSetTransColor: <https://www.autohotkey.com/docs/v2/lib/WinSetTransColor.htm>

공식 웹 문서 접근이 제한되는 경우 동일 프로젝트의 공식 문서 저장소에서 내용을 확인할 수 있습니다: <https://github.com/AutoHotkey/AutoHotkeyDocs/tree/v2/docs>

## 검증의 한계

Linux에서 파일 구조, 복원된 RGBA 픽셀, 알파, 핫스폿, 애니메이션 재생 순서와 시간, 결정적 출력, 손상된 입력 거부를 검증했습니다. Pillow의 별도 CUR 판독기로 정적 커서의 포맷과 크기도 확인했습니다. Windows 네이티브 로더, 마우스 속성, CMD 설치·복원, AutoHotkey 프로그램은 이 환경에서 실행하지 않았습니다. 따라서 실제 Windows 실행 완료를 주장하지 않습니다.
