@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Eden Everyday - Restore
if not defined LOCALAPPDATA goto missing
set "EDEN_ROOT=%LOCALAPPDATA%\EdenCursorTheme"
if not exist "%EDEN_ROOT%\latest-backup-id.txt" goto missing
findstr.exe /R /X "install-[0-9][0-9]*-[0-9][0-9]*-[0-9][0-9]*" "%EDEN_ROOT%\latest-backup-id.txt" >nul
if errorlevel 1 goto missing
set /p EDEN_ID=<"%EDEN_ROOT%\latest-backup-id.txt"
set "EDEN_RESTORE=%EDEN_ROOT%\Backups\%EDEN_ID%\Restore_This_Backup.cmd"
if not exist "%EDEN_RESTORE%" goto missing
"%ComSpec%" /D /S /C ""%EDEN_RESTORE%""
exit /b %errorlevel%
:missing
echo No valid Eden install backup was found for this user.
echo Check %%LOCALAPPDATA%%\EdenCursorTheme\Backups for older recovery scripts.
echo You can also select Windows Default in Mouse Properties, Pointers.
start "" control.exe main.cpl,,1
pause
exit /b 1
